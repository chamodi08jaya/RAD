import java.util.Scanner;
class time{
	public static void main(String args[]){
	Scanner obj1=new Scanner(System.in);
	
	
	System.out.println("Enter time in seconds:");
	int x=obj1.nextInt();
	
	int y,z,m,k;
	y=x/3600;
	z=x%3600;
	m=z/60;
	k=z%60;
	System.out.println(y + " Hour "+m+" minute "+k+" seconds ");
	
	
	}
	}