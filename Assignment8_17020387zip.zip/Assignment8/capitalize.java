import java.util.Scanner;
class capitalize{
	public static void main(String args[]){
	Scanner obj1=new Scanner(System.in);
	
	System.out.println("Enter a word:");
	String x=obj1.nextLine();
	
	stringUtils.capitalize(x);
	
	
	
	
	}
}
	
	
	
	