import java.util.Scanner;
class accept{
	public static void main(String args[]){
	Scanner obj1=new Scanner(System.in);
	
	
	System.out.println("Enter first number:");
	int x=obj1.nextInt();
	System.out.println("Enter second number:");
	int y=obj1.nextInt();
	System.out.println("Enter third number:");
	int z=obj1.nextInt();
	
	if(x%10==y%10||x%10==z%10||y%10==z%10){
		System.out.println("TRUE");
	}else{
		System.out.println("FALSE");
	}		
}
}