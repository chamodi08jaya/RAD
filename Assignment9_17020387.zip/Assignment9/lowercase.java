import java.util.Scanner;
class lowercase{
	public static void main(String args[]){
	Scanner obj1=new Scanner(System.in);
	
	System.out.println("Enter a string:");
	String x = obj1.nextLine();
	
	System.out.println(x.toLowerCase()); 
	
}
}