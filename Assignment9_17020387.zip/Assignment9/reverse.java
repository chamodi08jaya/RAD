import java.util.Scanner;
class reverse{
	public static void main(String args[]){
	Scanner obj1=new Scanner(System.in);
	
	
	System.out.println("Enter a word:");
	String x=obj1.nextLine();
	
	
	StringBuilder obj2=new StringBuilder();
	obj2.append(x);
	obj2=obj2.reverse();
	System.out.println("Reverse word:"+obj2);
	
	
	
	
	
	
	}
}