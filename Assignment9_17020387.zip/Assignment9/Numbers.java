import java.util.Scanner;
class Numbers{
	public static void main(String args[]){
	Scanner obj1=new Scanner(System.in);
	
	
	System.out.println("Enter a first Number:");
	int x= obj1.nextInt(); 

	System.out.println("Enter a second Number :");
	int y = obj1.nextInt();
	
	if(x>=50 && x<=100){
		if(y>=50 && y<=100){
			int z=x/10;
			int m=y/10;
			int a=x%10;
			int b=y%10;
			if(z==a||z==b||m==a||m==b){
				System.out.println("True");
			}	
		
		}
		
	}
	
	
	
	
	
	}
}

















 