import java.util.Scanner;
class count{
	public static void main(String args[]){
	Scanner obj1=new Scanner(System.in);
	
	System.out.println("Enter a string:");
	String x = obj1.nextLine();
	
	System.out.println("Length of the String is: " + x.length());
	char[] string=x.toCharArray();
	int letters=0;
	int numbers=0;
	int spaces=0;
	int other_characters=0;
	for(int i = 0; i < x.length(); i++){
		if(Character.isLetter(string[i])){
				letters ++ ;
			}
			else if(Character.isDigit(string[i])){
				numbers ++ ;
			}
			else if(Character.isSpaceChar(string[i])){
				spaces ++ ;
			}
			else{
				other_characters ++;
			}
	}
	System.out.println(" count the letters:" +letters);
	System.out.println(" count the numbers:" +numbers );
	System.out.println(" count the spaces :" +spaces  );
	System.out.println(" count the other_characters:" +other_characters );

	
}
}





			