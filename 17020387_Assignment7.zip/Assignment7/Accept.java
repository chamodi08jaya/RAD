import java.util.Scanner;

class Accept{
	public static void main(String args[]){
		Scanner obj1=new Scanner(System.in);
		System.out.println("Enter a number:");
		int x=obj1.nextInt();
		if(x%2==0){
				System.out.println("1");
			
		}else{
			System.out.println("0");
		}
		
	
	}


}