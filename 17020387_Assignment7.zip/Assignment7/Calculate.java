import java.util.Scanner;

class Calculate{
	
	
	
	public static void main(String args[]){
		Scanner obj1=new Scanner(System.in);
		Calculate c=new Calculate();
		System.out.println("Enter first number:");
		int x=obj1.nextInt();
		System.out.println("Enter second number:");
		int y=obj1.nextInt();
		System.out.println("Enter third number:");
		int z=obj1.nextInt();
		
		
		int answer=x+y;
		
			if(x+y==z||x+z==y||y+z==x){
			System.out.println("TRUE");
	
		}

}
}