 public class ka{
	public static void main(String args[]){
		
		String z = "123";
		System.out.println("String input:"+z);
		int x= Integer.parseInt(z);
		System.out.println("String convert into int "+x);
	}
}