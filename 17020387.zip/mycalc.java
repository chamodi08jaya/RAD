import java.util.Scanner;
public class mycalc{
	public static void main(String[] args){
		Scanner obj=new Scanner(System.in);
		myprint obj1=new myprint();
		
		System.out.println("Enter Value:");
		obj1.x=obj.nextInt();
		System.out.println("Enter Value:");
		obj1.y=obj.nextInt();
		
		System.out.println("x+y="+obj1.add(obj1.x,obj1.y));
		System.out.println("x-y="+obj1.sub(obj1.x,obj1.y));
		System.out.println("x/y="+obj1.div(obj1.x,obj1.y));
		System.out.println("x*y="+obj1.mul(obj1.x,obj1.y));
		}

}
class myprint{
	int x,y;	
	public int add(int x,int y){
		return x + y;
	}
	public int sub(int x,int y){
		return x - y;
	}
	public int div(int x,int y){
		return x / y;
	}
	public int mul(int x,int y){
		return x * y;
	}
 }


