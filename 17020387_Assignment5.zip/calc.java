import java.util.Scanner;


class Calculator{
	private double x;
	private double y;
	public void add(){
	System.out.println("X+Y="+(x+y));
	}
	public void sub(){
	System.out.println("X-Y="+(x-y));
	}
	public void mul(){
	System.out.println("X*Y="+(x*y));
	}
	public void div(){
	System.out.println("X/Y="+(x/y));
	}
	
	
	//getter
	public double getX(){
		return x;
	}
	
	public double getY(){
		return y;
	}
	//setter
	public void setX(double newX){
		this.x=newX;
	
	}
	public void setY(double newY){
		this.y=newY;
	
	}
}
public class calc{	
	public static void main (String args[]){
		double x,y;
		char z;
		
		Scanner obj1=new Scanner(System.in);
		
		System.out.println("Enter First Value :");
		x=obj1.nextDouble();
		
		System.out.println("Enter Second Value :");
		y=obj1.nextDouble();
		
		System.out.println("Enter operator +,-,*,/:");
		z=obj1.next().charAt(0);
		
		
		Calculator c=new Calculator();
		c.setX(x);  
		c.setY(y);
		
		if(z=='+'){
			c.add();
		}else if(z=='-'){
			c.sub();
		}else if(z=='*'){
			c.mul();
		}else{
			c.div();
		}
	
	}
}