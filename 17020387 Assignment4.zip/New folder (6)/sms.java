 class Student{
	private String name;
	private int indexNo;
	//getter
	public String getName(){
		return name;
	}
	
	public int getIndexNo(){
		return indexNo;
	}
	//setter
	public void setName(String newName){
		this.name=newName;
	
	}
	public void setIndexNo(int newIndexNo){
		this.indexNo=newIndexNo;
	
	}
}

public class sms{
	public static void main(String args[]){
		Student s1=new Student();
		Student s2=new Student();
		Student s3=new Student();
		Student s4=new Student();
		Student s5=new Student();
		
		s1.setName("Chamo");  
		s1.setIndexNo(01);
		
		s2.setName("Kamal");  
		s2.setIndexNo(02);
		
		s3.setName("Kamala");  
		s3.setIndexNo(03);
		
		s4.setName("Nimal");  
		s4.setIndexNo(04);
		
		s5.setName("Nimali");  
		s5.setIndexNo(05);
		
		System.out.println("The index number of "+s1.getName()+" is "+s1.getIndexNo()); 
		System.out.println("The index number of "+s2.getName()+" is "+s2.getIndexNo());
		System.out.println("The index number of "+s3.getName()+" is "+s3.getIndexNo());
		System.out.println("The index number of "+s4.getName()+" is "+s4.getIndexNo());
		System.out.println("The index number of "+s5.getName()+" is "+s5.getIndexNo());
	
	}
}