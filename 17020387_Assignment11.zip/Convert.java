import java.util.Scanner;


public class Convert{
		public static void main(String[] args){
			
			Scanner obj1=new Scanner(System.in);
			System.out.println("Enter a binary number:");
			String x = obj1.nextLine();
			
			System.out.println(Integer.parseInt(x,2));
			
		}
			
}