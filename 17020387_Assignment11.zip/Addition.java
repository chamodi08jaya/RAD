import java.util.Scanner;


public class Addition{
		public static void main(String[] args){
			
			Scanner obj1=new Scanner(System.in);

			System.out.println("Enter a first binary number:");
			int x = obj1.nextInt();

			System.out.println("Enter a second binary number:");
			int y = obj1.nextInt();
			
			int[] add=new int[10];
			int remains=0,i=0;
			while(x!=0||y!=0){
				add[i++]=(x%10+y%10+remains)%2;
				remains=(x%10+y%10+remains)/2;
				x=x/10;
				y=y/10;
			}
			if(remains!=0){
					add[i++]=remains;
			}
			--i;
			System.out.println("Sum of two binary numbers:");
			while(i>=0){
				System.out.print(add[i--]);
			}


		}

}