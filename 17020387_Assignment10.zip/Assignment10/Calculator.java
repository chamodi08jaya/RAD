import java.util.Scanner;

class Calculator{
	
	public static void main(String args[]){
	Scanner obj1=new Scanner(System.in);
	try{
		System.out.println("Enter first input:");
		int x= obj1.nextInt();
	
		System.out.println("Enter second input:");
		int y= obj1.nextInt();
	
		System.out.println("Enter an operator (+, -, *, /): ");
        	char z= obj1.next().charAt(0);
		int answer;
	
		switch(z)
        	{
            		case '+':
                		answer=x + y;
                		break;

            		case '-':
                		answer=x - y;
               			 break;

            		case '*':
                		answer=x * y;
                		break;
	    
            		case '/':
                		answer=x / y;
                		break;
	   
            		default:
                		System.out.println("Incorrect operator");
                		return;
        	}

		System.out.printf("%.1d %c %.1d = %.1d",x,z,y,answer);
	}
	
	catch (Exception e){
		System.out.println("Error\n"+e);
		
	}

    }
	
}	