import java.util.Scanner;
public class rocket  {
	public static void main(String[] args){
	
	Scanner obj=new Scanner(System.in);
	
	System.out.println("Enter Value of total mass in kilograms:");
	float x=obj.nextFloat();
	
	System.out.println("Enter Value of total thrust in kilograms:");
	float y=obj.nextFloat();
	
	float weight= x* 9.8f;
	float resultanforce=y - weight;
	
	float a= resultanforce / x;
	System.out.println("Value of total acceleration:" +a);
	
	}
}